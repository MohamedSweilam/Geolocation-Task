﻿namespace Geolocation_Task.Models
{
    public class BlockedCountryRequest
    {
        public string CountryCode { get; set; }
        public string CountryName { get; set; }
    }
}
